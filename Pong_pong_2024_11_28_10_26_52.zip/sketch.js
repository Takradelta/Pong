function setup()
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let ball;

let playerPaddle, opponentPaddle;

let playerScore = 0;

let opponentScore = 0;

let ballSpeedX = 5;

let ballSpeedY = 5;

function setup() {

  createCanvas(800, 600);

  ball = new Ball();

  playerPaddle = new Paddle(30);

  opponentPaddle = new Paddle(width - 50);

}

function draw() {

  background(0);
  

  // Desenhar a bola e as paddles

  ball.update();

  ball.show();

  ball.checkEdges();

  ball.checkPaddle(playerPaddle);

  ball.checkPaddle(opponentPaddle);

  playerPaddle.update(true);

  opponentPaddle.update(false);

  playerPaddle.show();

  opponentPaddle.show();

  // Mostrar o placar

  fill(255);

  textSize(32);

  textAlign(CENTER, CENTER);

  text(playerScore, width / 4, 50);

  text(opponentScore, (width / 4) * 3, 50);

}

class Ball {

  constructor() {

    this.x = width / 2;

    this.y = height / 2;

    this.diameter = 20;

    this.speedX = ballSpeedX;

    this.speedY = ballSpeedY;

  }

  update() {

    this.x += this.speedX;

    this.y += this.speedY;

  }

  show() {

    fill(255);

    ellipse(this.x, this.y, this.diameter);

  }

  checkEdges() {

    // Rebater na parede superior e inferior

    if (this.y < 0 || this.y > height) {

      this.speedY *= -1;

    }

    // Pontuação para jogador ou oponente

    if (this.x < 0) {

      opponentScore++;

      this.reset();

    } else if (this.x > width) {

      playerScore++;

      this.reset();

    }

  }

  checkPaddle(paddle) {

    if (

      this.x - this.diameter / 2 < paddle.x + paddle.w &&

      this.x + this.diameter / 2 > paddle.x &&

      this.y > paddle.y &&

      this.y < paddle.y + paddle.h

    ) {

      this.speedX *= -1;

    }

  }

  reset() {

    this.x = width / 2;

    this.y = height / 2;

    this.speedX = ballSpeedX * (random() > 0.5 ? 1 : -1);

    this.speedY = ballSpeedY * (random() > 0.5 ? 1 : -1);

  }

}

class Paddle {

  constructor(x) {

    this.x = x;

    this.y = height / 2 - 50;

    this.w = 20;

    this.h = 100;

    this.speed = 7;

  }

  update(isPlayer) {

    if (isPlayer) {

      if (keyIsDown(UP_ARROW)) {

        this.y -= this.speed;

      }

      if (keyIsDown(DOWN_ARROW)) {

        this.y += this.speed;

      }

    } else {

      // Movimento simples para o oponente (segue a bola)

      if (ball.y < this.y + this.h / 2) {

        this.y -= this.speed;

      } else if (ball.y > this.y + this.h / 2) {

        this.y += this.speed;

      }

    }

    // Limitar dentro da tela

    this.y = constrain(this.y, 0, height - this.h);

  }

  show() {

    fill(255);

    rect(this.x, this.y, this.w, this.h);

  }

}